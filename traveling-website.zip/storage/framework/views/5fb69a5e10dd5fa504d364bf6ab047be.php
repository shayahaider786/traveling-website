<div class="table-responsive">
    <table class="display table table-striped table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Rating</th>
                <th>Comment</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($review->name); ?></td>
                <td><?php echo e($review->email); ?></td>
                <td>
                    <?php for($i = 1; $i <= 5; $i++): ?>
                        <i class="fas fa-star <?php echo e($i <= $review->rating ? 'text-warning' : 'text-secondary'); ?>"></i>
                    <?php endfor; ?>
                </td>
                <td><?php echo e(Str::limit($review->comment, 50)); ?></td>
                <td>
                    <?php if($review->is_approved == 1): ?>
                        <span class="badge bg-success">Approved</span>
                    <?php elseif($review->is_approved == 0): ?>
                        <span class="badge bg-danger">Rejected</span>
                    <?php else: ?>
                        <span class="badge bg-warning">Pending</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($review->created_at->format('M d, Y')); ?></td>
                <td>
                    <?php if($review->is_approved !== true): ?>
                        <a href="<?php echo e(route('admin.reviews.approve', $review->id)); ?>" class="btn btn-success btn-sm">Approve</a>
                    <?php endif; ?>

                    <?php if($review->is_approved !== false): ?>
                        <a href="<?php echo e(route('admin.reviews.reject', $review->id)); ?>" class="btn btn-warning btn-sm">Reject</a>
                    <?php endif; ?>

                    <form action="<?php echo e(route('admin.reviews.destroy', $review->id)); ?>" method="POST" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this review?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php /**PATH D:\shayanProject\tourism-website-template\travelWithShAdventure\resources\views/backend/reviews/partials/reviews-table.blade.php ENDPATH**/ ?>