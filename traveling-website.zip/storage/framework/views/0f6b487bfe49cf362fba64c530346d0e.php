<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="d-flex justify-content-between align-items-center pt-2 pb-4">
            <div>
                <h3 class="fw-bold mb-3">Packages</h3>
            </div>
            <div class="ml-md-auto py-2 py-md-0">
                <a href="<?php echo e(route('admin.packages.create')); ?>" class="btn btn-primary">Add New Package</a>
            </div>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Packages List</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Destination</th>
                                        <th>Package Name</th>
                                        <th>Price</th>
                                        <th>Days</th>
                                        <th>Person</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td> 
                                        <td><?php echo e($package->destination->destination_name); ?></td>
                                        <td><?php echo e($package->package_name); ?></td>
                                        <td>PKR <?php echo e(number_format($package->package_price, 2)); ?></td>
                                        <td><?php echo e($package->package_days); ?> Days</td>
                                        <td><?php echo e($package->package_person); ?> Person</td>
                                        <td><img src="<?php echo e(asset($package->package_picture)); ?>" alt="<?php echo e($package->package_name); ?>" width="100"></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.packages.show', $package->id)); ?>" class="btn btn-info btn-sm">View</a>
                                            <a href="<?php echo e(route('admin.packages.edit', $package->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                            <form action="<?php echo e(route('admin.packages.destroy', $package->id)); ?>" method="POST" style="display: inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this package?')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\shayan data\tourism-website-template\travelWithShAdventure\resources\views/backend/packages/index.blade.php ENDPATH**/ ?>