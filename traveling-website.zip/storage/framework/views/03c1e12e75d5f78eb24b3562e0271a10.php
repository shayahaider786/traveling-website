<?php $__env->startSection('content'); ?>
    <!-- Header Start -->
    <div class="container-fluid bg-breadcrumb">
        <div class="container text-center py-5" style="max-width: 900px;">
            <h3 class="text-white display-3 mb-4">Our Services</h1>
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Pages</a></li>
                    <li class="breadcrumb-item active text-white">Services</li>
                </ol>
        </div>
    </div>
    <!-- Header End -->

    <!-- Services Start -->
    <div class="container-fluid bg-light service py-5">
        <div class="container py-5">
            <div class="mx-auto text-center mb-5" style="max-width: 900px;">
                <h5 class="section-title px-3">Searvices</h5>
                <h1 class="mb-0">Our Services</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="row g-4">
                        <div class="col-12">
                            <div
                                class="service-content-inner d-flex align-items-center bg-white border border-primary rounded p-4 ps-0">
                                <div class="service-icon p-4">
                                    <i class="fa fa-globe fa-4x text-primary"></i>
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-4">Luxury Transport</h5>
                                    <p class="mb-0">Dolor sit amet consectetur adipisicing elit. Non alias eum, suscipit
                                        expedita corrupti officiis debitis possimus nam laudantium beatae quidem dolore
                                        consequuntur voluptate rem reiciendis, omnis sequi harum earum.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div
                                class="service-content-inner d-flex align-items-center bg-white border border-primary rounded p-4 ps-0">
                                <div class="service-icon p-4">
                                    <i class="fa fa-user fa-4x text-primary"></i>
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-4">Travel Guides</h5>
                                    <p class="mb-0">Dolor sit amet consectetur adipisicing elit. Non alias eum, suscipit
                                        expedita corrupti officiis debitis possimus nam laudantium beatae quidem dolore
                                        consequuntur voluptate rem reiciendis, omnis sequi harum earum.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row g-4">

                        <div class="col-12">
                            <div
                                class="service-content-inner d-flex align-items-center bg-white border border-primary rounded p-4 ps-0">
                                <div class="service-icon p-4">
                                    <i class="fa fa-hotel fa-4x text-primary"></i>
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-4">Hotel Reservation</h5>
                                    <p class="mb-0">Dolor sit amet consectetur adipisicing elit. Non alias eum, suscipit
                                        expedita corrupti officiis debitis possimus nam laudantium beatae quidem dolore
                                        consequuntur voluptate rem reiciendis, omnis sequi harum earum.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div
                                class="service-content-inner d-flex align-items-center bg-white border border-primary rounded p-4 ps-0">
                                <div class="service-icon p-4">
                                    <i class="fa fa-cog fa-4x text-primary"></i>
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-4">Photography</h5>
                                    <p class="mb-0">Dolor sit amet consectetur adipisicing elit. Non alias eum, suscipit
                                        expedita corrupti officiis debitis possimus nam laudantium beatae quidem dolore
                                        consequuntur voluptate rem reiciendis, omnis sequi harum earum.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Services End -->

    <!-- Testimonial Start -->
    <div class="container-fluid testimonial py-5">
        <div class="container py-5">
            <div class="mx-auto text-center mb-5" style="max-width: 900px;">
                <h5 class="section-title px-3">Testimonial</h5>
                <h1 class="mb-0">Our Clients Say!!!</h1>
            </div>
            <div class="text-end m-5">
                <a href="<?php echo e(route('review.create')); ?>" class="btn btn-primary rounded-pill px-4 py-2">Add Review</a>
            </div>
            <div class="testimonial-carousel owl-carousel">
                <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="testimonial-item text-center rounded pb-4">
                        <div class="testimonial-comment bg-light rounded p-4">
                            <p class="text-center mb-5"><?php echo e($review->comment); ?></p>
                        </div>
                        
                        <div class="mt-3">
                            <h5 class="mb-0"><?php echo e($review->name); ?></h5>
                            <div class="d-flex justify-content-center">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star <?php echo e($i <= $review->rating ? 'text-primary' : 'text-light'); ?>"></i>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center">
                        <p>No reviews available yet. Be the first to leave a review!</p>
                        <a href="<?php echo e(route('review.create')); ?>" class="btn btn-primary mt-3">Add Review</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\shayanProject\tourism-website-template\travelWithShAdventure\resources\views/frontend/service.blade.php ENDPATH**/ ?>