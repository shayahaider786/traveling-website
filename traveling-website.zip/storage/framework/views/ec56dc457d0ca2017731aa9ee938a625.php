<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="d-flex justify-content-between align-items-center pt-2 pb-4">
            <div>
                <h3 class="fw-bold mb-3">Package Details</h3>
            </div>
            <div class="ml-md-auto py-2 py-md-0">
                <a href="<?php echo e(route('admin.packages.index')); ?>" class="btn btn-primary">Back to Packages</a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Package Details</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="destination_id">Destination</label>
                                    <p><?php echo e($package->destination->destination_name); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="package_name">Package Name</label>
                                    <p><?php echo e($package->package_name); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="package_price">Price</label>
                                    <p>PKR<?php echo e(number_format($package->package_price, 2)); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="package_days">Days</label>
                                    <p><?php echo e($package->package_days); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="package_person">Total Person</label>
                                    <p><?php echo e($package->package_person); ?></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="package_description">Package Short Description</label>
                                    <p><?php echo e($package->package_description); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="package_long_description">Package Long Description</label>
                                    <p><?php echo e($package->package_long_description); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\shayan data\tourism-website-template\travelWithShAdventure\resources\views/backend/packages/show.blade.php ENDPATH**/ ?>