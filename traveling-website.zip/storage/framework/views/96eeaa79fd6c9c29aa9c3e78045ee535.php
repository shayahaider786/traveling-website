<?php $__env->startSection('content'); ?>
    <!-- Header Start -->
    <div class="container-fluid bg-breadcrumb">
        <div class="container text-center py-5" style="max-width: 900px;">
            <h3 class="text-white display-3 mb-4">Our Services</h1>
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                    <li class="breadcrumb-item active text-white">Services</li>
                </ol>
        </div>
    </div>
    <!-- Header End -->

    <!-- Services Start -->
    <div class="container-fluid bg-light service py-5">
        <div class="container py-5">
            <div class="mx-auto text-center mb-5" style="max-width: 900px;">
                <h5 class="section-title px-3">Searvices</h5>
                <h1 class="mb-0">Our Services</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="row g-4">
                        <div class="col-12">
                            <div
                                class="service-content-inner d-flex align-items-center bg-white border border-primary rounded p-4 ps-0">
                                <div class="service-icon p-4">
                                    <i class="fa fa-globe fa-4x text-primary"></i>
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-4">WorldWide Tours</h5>
                                    <p class="mb-0">Northern Pakistan is a breathtaking region known for its majestic
                                        mountains, serene valleys, and rich cultural heritage. From the snow-capped peaks of
                                        the Karakoram to the lush meadows of Swat, this area offers a diverse range of
                                        experiences for travelers. Tour services in this region are designed to provide a
                                        seamless and enriching journey, covering all essential aspects: accommodation, food,
                                        travel, and guided activities.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div
                                class="service-content-inner d-flex align-items-center bg-white border border-primary rounded p-4 ps-0">
                                <div class="service-icon p-4">
                                    <i class="fa fa-user fa-4x text-primary"></i>
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-4">Travel Guides</h5>
                                    <p class="mb-0">Travel and transport are well-managed by tour companies, ensuring safe
                                        and comfortable journeys through the mountainous terrain. Depending on the group
                                        size and destination, transport may include private cars, coasters, or 4x4 jeeps for
                                        rugged tracks. Some packages also include domestic flights, such as from Islamabad
                                        to Skardu, to save time and offer aerial views of the mountains. Airport pick-up and
                                        drop-off services are commonly included, along with intercity transfers and
                                        sightseeing transport.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row g-4">

                        <div class="col-12">
                            <div
                                class="service-content-inner d-flex align-items-center bg-white border border-primary rounded p-4 ps-0">
                                <div class="service-icon p-4">
                                    <i class="fa fa-hotel fa-4x text-primary"></i>
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-4">Hotel Reservation</h5>
                                    <p class="mb-0">Guided activities are a highlight of Northern Pakistan tours.
                                        Experienced local guides lead cultural tours to historical sites like Baltit Fort,
                                        Altit Fort, and Shigar Fort. Adventure seekers can join trekking expeditions to
                                        Nanga Parbat Base Camp or explore the vast Deosai National Park. Other popular
                                        activities include boating on Attabad Lake, visiting the Kalash Valley to experience
                                        its unique culture, and shopping in local bazaars for handicrafts and dry fruits.
                                        Tour operators often customize itineraries based on interests—whether it's
                                        photography, hiking, or cultural immersion.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div
                                class="service-content-inner d-flex align-items-center bg-white border border-primary rounded p-4 ps-0">
                                <div class="service-icon p-4">
                                    <i class="fa fa-cog fa-4x text-primary"></i>
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-4">Food</h5>
                                    <p class="mb-0">Food is an integral part of the travel experience, and tour services
                                        typically include daily breakfast, with some offering full board meals often feature
                                        traditional Pakistani cuisine, including dishes like chapli kebab, chicken karahi,
                                        and daal chawal. In places like Hunza, travelers can enjoy local specialties such as
                                        apricot soup and walnut cake. Tour operators also accommodate dietary preferences
                                        and ensure hygienic food options, whether served at hotels, local restaurants, or
                                        during outdoor excursions.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="text-center">
                        <a class="btn btn-primary rounded-pill py-3 px-5 mt-2" href="<?php echo e(route('service')); ?>">Service More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Services End -->

    <!-- Testimonial Start -->
    <div class="container-fluid testimonial py-5">
        <div class="container py-5">
            <div class="mx-auto text-center mb-5" style="max-width: 900px;">
                <h5 class="section-title px-3">Testimonial</h5>
                <h1 class="mb-0">Our Clients Say!!!</h1>
            </div>
            <div class="text-end m-5">
                <a href="<?php echo e(route('review.create')); ?>" class="btn btn-primary rounded-pill px-4 py-2">Add Review</a>
            </div>
            <div class="testimonial-carousel owl-carousel">
                <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="testimonial-item text-center rounded pb-4">
                        <div class="testimonial-comment bg-light rounded p-4">
                            <p class="text-center mb-5"><?php echo e($review->comment); ?></p>
                        </div>
                        
                        <div class="mt-3">
                            <h5 class="mb-0"><?php echo e($review->name); ?></h5>
                            <div class="d-flex justify-content-center">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star <?php echo e($i <= $review->rating ? 'text-primary' : 'text-light'); ?>"></i>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center">
                        <p>No reviews available yet. Be the first to leave a review!</p>
                        <a href="<?php echo e(route('review.create')); ?>" class="btn btn-primary mt-3">Add Review</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\shayanProject\traveling-website\resources\views/frontend/service.blade.php ENDPATH**/ ?>